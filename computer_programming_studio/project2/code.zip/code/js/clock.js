//if 7 am

  setInterval(function (){

    var number7 = document.getElementById("n7")
    var shadow= number7.style.textShadow;
    var myDate = new Date;

    var currentSecond = myDate.getSeconds()
    var currentMinute = myDate.getMinutes()

    var shadow = "";
    var y= 0;
    var x= 0;

    for (var i = 0; i < currentMinute; i++) {//this is what im not getting...

    shadow = shadow + `${x}px ${y}px black,`

    var y=y+1;
    var x=y*(-2);
    }

    number7.style.textShadow = shadow;
    //number7.style.fontSize = "200px"
    //number7.style.color = "red"


    console.log(shadow);



}, 1000)//every 35 seconds the shadow moves/adds/subtractys by (-2,1)


/*
take the time

change the number div based on the time

edit the css of the number div so that the textshadow reflects the time of day (ex if its 7 pm the shadow div should extend to y=200px, that means it will have to generate new shadows and add them to the existing one)

have the code add to the textshadow in an equation format constantly until the necassary number of shadow texts is reached
*/


/*var n7 = document.getElementById("n7");
console.log(n7)

var shadow=n7.style.textShadow

shadow= `(${x} ${y}) black,`;

var y= 1;
var x= -2;

while( y< 200px){

  //MISSING PART: a duplicate of the previous shadow has to made and then the following code that moves it has to be applied to it after which another copy is made and the process is repeated
  var y=y+1;
  var x=(y+1)*2;
  //for the text-shadow every next "shadow number" moves down to line up with the other numbers to extend the shadows until "y" is equal to 200px meaning x would be 400px
  console.log(y)
  console.log(x)
}

*/
